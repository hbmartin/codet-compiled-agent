"""Verified, clean archive extraction shared by dependency provisioning and builds."""
import errno
import hashlib
import pathlib
import shutil
import tarfile
import tempfile


def file_hash(path, buffer=None):
    with pathlib.Path(path).open('rb') as source:
        return stream_hash(source, buffer)

def stream_hash(source, buffer=None):
    digest = hashlib.sha256()
    if hasattr(source, 'readinto'):
        buffer = buffer if buffer is not None else bytearray(64 * 1024)
        view = memoryview(buffer)
        while True:
            count = source.readinto(buffer)
            if not count:
                break
            digest.update(view[:count])
    else:
        for chunk in iter(lambda: source.read(64 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def tree_hashes(root, *, exclude_manifest=False):
    root = pathlib.Path(root)
    result = {}
    for path in sorted(root.rglob('*')):
        if path.name == '.DS_Store' or (exclude_manifest and path == root / 'manifest.json'):
            continue
        name = path.relative_to(root).as_posix()
        if path.is_symlink():
            result[name] = 'link:' + str(path.readlink())
        elif path.is_file():
            result[name] = file_hash(path)
    return result

def remove_tree(path):
    # Finder can recreate directory metadata while a bind-mounted tree is removed.
    for attempt in range(4):
        try:
            shutil.rmtree(path)
            return
        except FileNotFoundError:
            if not pathlib.Path(path).exists():
                return
            raise
        except OSError as error:
            if error.errno != errno.ENOTEMPTY or attempt == 3:
                raise


def extract_verified(archive, expected, destination):
    """Hash and extract the same open archive; never overlay a mutable source tree."""
    destination = pathlib.Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = pathlib.Path(tempfile.mkdtemp(prefix=destination.name + '-extract-', dir=destination.parent))
    try:
        with pathlib.Path(archive).open('rb') as source:
            if stream_hash(source) != expected:
                raise ValueError('Archive checksum mismatch: ' + str(archive))
            source.seek(0)
            with tarfile.open(fileobj=source) as package:
                prefix = None
                for member in package:
                    original = pathlib.PurePosixPath(member.name)
                    if original.is_absolute() or '..' in original.parts or not original.parts:
                        raise ValueError('Unsafe archive member: ' + member.name)
                    if prefix is None:
                        prefix = original.parts[0]
                    if original.parts[0] != prefix:
                        raise ValueError('Archive must have one source root')
                    relative = pathlib.PurePosixPath(*original.parts[1:])
                    if str(relative) == '.':
                        continue
                    member = member.replace(name=str(relative))
                    if member.islnk():
                        link = pathlib.PurePosixPath(member.linkname)
                        if link.is_absolute() or '..' in link.parts or not link.parts or link.parts[0] != prefix:
                            raise ValueError('Unsafe archive hard link')
                        member = member.replace(linkname=str(pathlib.PurePosixPath(*link.parts[1:])))
                    package.extract(member, staging, filter='data')
        if destination.is_symlink():
            raise ValueError('Source destination must not be a symlink')
        if destination.exists():
            remove_tree(destination)
        staging.rename(destination)
    finally:
        if staging.exists():
            remove_tree(staging)
