#!/usr/bin/env python3
import argparse
import hashlib
import pathlib
import subprocess

import tiger_provenance
from tiger_macho import MachO
from validation_evidence import atomic_json

ROOT=pathlib.Path(__file__).resolve().parents[1]
PREFIX='/usr/local/bin/powerpc-apple-darwin8-'

def output(*args):return subprocess.check_output(list(args),text=True,timeout=30)

def runtime_libraries(stage, prefix, system_root=None, inspection=None):
    inspection=inspection or MachO(output,PREFIX)
    stage=pathlib.Path(stage).resolve()
    required=['lib/libcurl.dylib','lib/libsqlite3.dylib','lib/libz.dylib',
              'lib/libncurses.dylib','lib/libedit.dylib',
              'libexec/openssl3/lib/libssl.dylib','libexec/openssl3/lib/libcrypto.dylib']
    for relative in required:
        path=stage/prefix.lstrip('/')/relative
        if not path.is_file() or not path.resolve().is_relative_to(stage):
            raise SystemExit('Missing or invalid required runtime library: '+str(path))
    pending=list(stage.rglob('*.dylib')); seen=set(); report=[]
    while pending:
        path=pending.pop()
        if not path.is_file(): raise SystemExit('Missing runtime library: '+str(path))
        library=path.resolve()
        if not library.is_relative_to(stage): raise SystemExit('Runtime library escapes sysroot: '+str(path))
        if library in seen: continue
        seen.add(library)
        inspection.architecture(library)
        dependencies=inspection.linkage(library)
        for line in dependencies.splitlines()[1:]:
            dep=line.strip().split(' ')[0]
            if dep.startswith(prefix+'/'):
                dependency=stage/dep.lstrip('/')
                if not dependency.is_file() or not dependency.resolve().is_relative_to(stage):
                    raise SystemExit('Unresolved target dependency: '+dep)
                pending.append(dependency)
            elif dep.startswith('/usr/lib/') or dep.startswith('/System/Library/Frameworks/'):
                if system_root is not None and not (pathlib.Path(system_root)/dep.lstrip('/')).is_file():
                    raise SystemExit('Unresolved SDK dependency: '+dep)
            else:
                raise SystemExit('Non-target transitive dependency: '+dep)
        report.append({'name':str(library.relative_to(stage)),'dependencies':dependencies,
                       'sha256':hashlib.sha256(library.read_bytes()).hexdigest()})
    return sorted(report,key=lambda item:item['name'])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-id')
    parser.add_argument('--provenance-sha256')
    args=parser.parse_args()
    context=tiger_provenance.resolve(ROOT,args.build_id,args.provenance_sha256)
    folder,provenance=context.folder,context.record
    inspection=MachO(output,PREFIX)
    for name in ("gcc","g++"):
        if tiger_provenance.compiler(pathlib.Path(PREFIX+name)) != provenance["compilers"][name]:
            raise ValueError("Verification compiler differs from producing build")
    prefix=context.manifest['prefix']
    report={'build_provenance_sha256':context.provenance_sha256,'build_id':folder.name,'target_runtime_verified':False,'compiler':output(PREFIX+'gcc','-dumpfullversion').strip(),'binaries':[]}
    if report['compiler']!='14.2.0':raise SystemExit('Wrong compiler')
    macros=output(PREFIX+'gcc','-m32','-mcpu=750','-mmacosx-version-min=10.4','-dM','-E','-x','c','/dev/null')
    for required in ['#define __SIZEOF_POINTER__ 4','#define __BIG_ENDIAN__ 1','#define __ENVIRONMENT_MAC_OS_X_VERSION_MIN_REQUIRED__ 1040']:
        if required not in macros.splitlines():raise SystemExit('Target macro mismatch: '+required)
    report['target_macros']=macros
    for name in ['codet','codet_tests','codet_persistence_bench']:
        p=folder/'native'/name;data=p.read_bytes()
        inspection.architecture(p,(9,),(2,))
        dependencies=inspection.linkage(p)
        for line in dependencies.splitlines()[1:]:
            dep=line.strip().split(' ')[0]
            if dep.startswith(prefix+'/') and not (ROOT/'build/tiger-sysroot'/dep.lstrip('/')).is_file():raise SystemExit('Unresolved binary dependency: '+dep)
            if not (dep.startswith('/usr/lib/') or dep.startswith(prefix+'/') or dep in ['/System/Library/Frameworks/'+f+'.framework/Versions/A/'+f for f in ['ApplicationServices','Carbon','CoreFoundation']]):raise SystemExit('Non-target dependency: '+dep)
        commands=inspection.load_commands(p)
        if 'LC_RPATH' in commands:raise SystemExit('Tiger does not support LC_RPATH')
        imports=output(PREFIX+'nm','-u',str(p))
        report['binaries'].append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'dependencies':dependencies,'imports':imports})
    report['runtime_libraries']=runtime_libraries(ROOT/'build/tiger-sysroot',prefix,'/usr/local/MacOSX10.4u.sdk',inspection)
    context.verify_sysroot()
    atomic_json(context.verification,report);print('Verified GCC 14.2, PPC32 big-endian/G3 Mach-O, target dependency paths, no LC_RPATH. PPC code was not executed.')

if __name__=='__main__':main()
