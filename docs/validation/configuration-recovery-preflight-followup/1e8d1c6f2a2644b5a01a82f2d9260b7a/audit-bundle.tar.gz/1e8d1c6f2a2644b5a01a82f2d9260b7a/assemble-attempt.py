import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent / "verifier_tooling"))
from evidence_attempt import main
main()
